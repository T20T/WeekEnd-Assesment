//
//  Team.swift
//  Notion
//
//  Created by Taghrid Alkwayleet on 30/10/1444 AH.
//

import SwiftUI
import YouTubePlayerKit
import MapKit

struct Team: View {
    @State private var region = MKCoordinateRegion(center: CLLocationCoordinate2D(latitude: 51.5, longitude: -0.12), span: MKCoordinateSpan(latitudeDelta: 0.2, longitudeDelta: 0.2))
    
    var body: some View{
       
        HStack(alignment:.bottom, spacing:2){
            Map(coordinateRegion: $region )
                .frame(maxWidth:.infinity ,maxHeight: 200)
                .padding()
                .padding(-300)
            YouTubePlayerView(
                       "https://www.youtube.com/watch?v=SvqldXKcRus"
                        
                   )
            .frame(maxWidth:.infinity ,maxHeight: 200)
            
            .padding(.bottom,-400)
            .padding(.horizontal,-200)
            
            
            
            Text("Resources")
                 .font(.largeTitle)
                 .bold()
                 .opacity(0.7)
                 .padding(.horizontal,-370)
                 .padding(.bottom,9)
            Text("_________________________________________________")
                 .font(.caption)
                 .bold()
                 .opacity(0.4)
                 .padding(.horizontal,-200)
                 .padding(.bottom,-5)
            
           
        }
       // Divider()
        
    }
    
}

struct Team_Previews: PreviewProvider {
    static var previews: some View {
        Team()
    }
}
