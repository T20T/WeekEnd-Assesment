//
//  EnterName.swift
//  Notion
//
//  Created by Taghrid Alkwayleet on 30/10/1444 AH.
//

import SwiftUI

struct EnterName: View {
 
        var body: some View {
            RoundedRectangle(cornerRadius: 2)
                .fill(Color.white)
                .overlay(RoundedRectangle(cornerRadius: 2)
                    .stroke(Color.blue, lineWidth: 5).opacity(0.2))
                .frame(maxWidth: .infinity, maxHeight: 50)
                .padding(.horizontal, 10)
               
                .overlay(
                    Text("John Mobbin")
                        .frame(maxWidth: .infinity, maxHeight: 50, alignment: .leading)
                        .foregroundColor(Color.black)
                        .padding()
                )
        }
    }

   

struct EnterName_Previews: PreviewProvider {
    static var previews: some View {
        EnterName()
    }
}
