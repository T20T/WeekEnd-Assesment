//
//  TextComponent.swift
//  Notion
//
//  Created by Taghrid Alkwayleet on 29/10/1444 AH.
//

import SwiftUI

struct TextComponent: View {
    var text: String
    
    var body: some View {
        Text(text)
            .frame(maxWidth: .infinity, maxHeight: 7, alignment: .topLeading)
            .foregroundColor(Color(UIColor.secondaryLabel))
            .font(.headline)
            .fontDesign(.rounded)
            .padding()
            .padding(.leading,-5)
    }
}

struct TextComponent_Previews: PreviewProvider {
    static var previews: some View {
        TextComponent(text: "write here")
    }
}
