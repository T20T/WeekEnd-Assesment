//
//  NameTextField.swift
//  Notion
//
//  Created by Taghrid Alkwayleet on 30/10/1444 AH.
//

import SwiftUI

extension TextField {
    func customTextField() -> some View {
        self
            .background(RoundedRectangle(cornerRadius: 2).fill(Color.white))
            .overlay(RoundedRectangle(cornerRadius: 2)
                .stroke(Color.blue, lineWidth: 5).opacity(0.2))
            .frame(maxWidth: .infinity, maxHeight: 50)
            .padding(.horizontal, 10)
            .overlay(
                Text("e.g. Ada Loveace, Ada, AL")
                    .frame(maxWidth: .infinity, maxHeight: 50, alignment: .leading)
                    .foregroundColor(Color(UIColor.secondaryLabel))
                    .padding()
            )
            .overlay(
                Text("|")
                    .frame(maxWidth: .infinity, maxHeight: 50, alignment: .leading)
                    .foregroundColor(Color.black)
                    .padding()
            )
    }
}
