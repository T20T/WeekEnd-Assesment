//
//  FirstTextField.swift
//  Notion
//
//  Created by Taghrid Alkwayleet on 29/10/1444 AH.
//

import SwiftUI

struct FirstTextField: View {
    var body: some View {
        RoundedRectangle(cornerRadius: 2)
            .fill(Color.white)
            .overlay(RoundedRectangle(cornerRadius: 2)
                .stroke(Color.blue, lineWidth: 5).opacity(0.2))
            .frame(maxWidth: .infinity, maxHeight: 50)
            .padding(.horizontal, 10)
            .overlay(
                Text("e.g. Ada Loveace, Ada, AL")
                    .frame(maxWidth: .infinity, maxHeight: 50, alignment: .leading)
                    .foregroundColor(Color(UIColor.secondaryLabel))
                    .padding()
            )
            .overlay(
                Text("|")
                    .frame(maxWidth: .infinity, maxHeight: 50, alignment: .leading)
                    .foregroundColor(Color.black)
                    .padding()
            )
    }
}

struct FirstTextField_Previews: PreviewProvider {
    static var previews: some View {
        FirstTextField()
    }
}
