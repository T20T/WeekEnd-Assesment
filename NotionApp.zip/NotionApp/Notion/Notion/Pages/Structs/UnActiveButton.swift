//
//  UnActiveButton.swift
//  Notion
//
//  Created by Taghrid Alkwayleet on 29/10/1444 AH.
//

import SwiftUI
struct UnActiveButton: View {
    var body: some View {
        RoundedRectangle(cornerRadius: 2)
            .fill(Color("UnActiveButton"))
            .overlay(
                RoundedRectangle(cornerRadius: 2)
                    .stroke(Color((UIColor.secondaryLabel)), lineWidth: 2).opacity(0.2))
            .frame(maxWidth: .infinity, maxHeight: 50)
            .padding(.horizontal, 10)
            .overlay(
                Text("Continue")
                    .font(.title3)
                    .frame(maxWidth: .infinity, maxHeight: 50, alignment: .center)
                    .foregroundColor(Color.white)
                    .padding()
            )
    }
}

struct UnActiveButton_Previews: PreviewProvider {
    static var previews: some View {
        UnActiveButton()
    }
}
