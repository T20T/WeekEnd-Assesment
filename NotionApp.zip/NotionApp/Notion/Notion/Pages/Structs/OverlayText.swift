//
//  OverlayText.swift
//  Notion
//
//  Created by Taghrid Alkwayleet on 29/10/1444 AH.
//

import SwiftUI

//struct OverlayText: View {
//    let text: String
//    let color: Color
//
//    var body: some View {
//        Text(text)
//                //.frame(maxWidth: .infinity, maxHeight: 50, alignment: .leading)
//                .foregroundColor(color)
////                .foregroundColor(color)
//                .padding()
//            }
//
//        }


struct OverlayText: View {
    var text: String
    var color: Color
    
    var body: some View {
        Text(text)
            .frame(maxWidth: .infinity, maxHeight: 50, alignment: .leading)
            .foregroundColor(color)
            .padding()
    }
}

struct OverlayText_Previews: PreviewProvider {
    static var previews: some View {
        OverlayText(text: "Some Text", color: .gray)
    }
}
