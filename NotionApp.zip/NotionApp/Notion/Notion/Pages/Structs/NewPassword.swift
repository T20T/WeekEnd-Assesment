//
//  NewPassword.swift
//  Notion
//
//  Created by Taghrid Alkwayleet on 29/10/1444 AH.
//

import SwiftUI

struct NewPassword: View {
    var body: some View {
        
        RoundedRectangle(cornerRadius: 2)
            .fill(Color.white)
            .overlay(RoundedRectangle(cornerRadius: 2)
                .stroke(Color(UIColor.secondaryLabel), lineWidth: 2).opacity(0.2))
            .frame(maxWidth: .infinity, maxHeight: 50)
            .padding(.horizontal, 10)
            .overlay(
                Text("New password")
                    .frame(maxWidth: .infinity, maxHeight: 50, alignment: .leading)
                    .foregroundColor(Color(UIColor.secondaryLabel))
                    .padding()
            )
            .overlay(
                Image(systemName: "eye")
                    .frame(maxWidth: .infinity, maxHeight: 50, alignment: .trailing)
                    .foregroundColor(Color(UIColor.secondaryLabel))
                    .padding()
            )
    }
}



struct NewPassword_Previews: PreviewProvider {
    static var previews: some View {
        NewPassword()
    }
}
