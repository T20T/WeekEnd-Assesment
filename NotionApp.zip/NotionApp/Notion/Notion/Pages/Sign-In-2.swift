//
//  Sign-In-2.swift
//  Notion
//
//  Created by Taghrid Alkwayleet on 29/10/1444 AH.
//

import SwiftUI

struct Sign_In_2: View {
    var body: some View {
        NavigationView {
            
            
            VStack(alignment: .leading, spacing:2) {
                
                Text("Cancel")
                    .foregroundColor(Color(UIColor.secondaryLabel))
                    .frame(maxWidth: .infinity, maxHeight: 55, alignment: .topLeading)
                    .padding()
                Text("Welcome To Notion")
                    .frame(maxWidth: .infinity, maxHeight: 40, alignment: .top)
                    .font(.title)
                    .bold()
                    .fontDesign(.rounded)
                Text("First, tell us a bit about yourself")
                    .frame(maxWidth: .infinity, maxHeight: 80, alignment: .top)
                    .foregroundColor(Color(UIColor.secondaryLabel))
                    .font(.title3)
                    .fontDesign(.rounded)
                
                TextComponent(text: "What should we call you?")
                RoundedRectangle(cornerRadius: 2)
                    .fill(Color.white)
                    .overlay(RoundedRectangle(cornerRadius: 2)
                        .stroke(Color(UIColor.secondaryLabel), lineWidth: 2).opacity(0.2))
                
                    .frame(maxWidth: .infinity, maxHeight: 50)
                    .padding(.horizontal, 10)
                
                    .overlay(
                        Text("Jone Mobbin")
                            .frame(maxWidth: .infinity, maxHeight: 50, alignment: .leading)
                            .foregroundColor(Color.black)
                            .opacity(0.7)
                            .font(.body)
                            .padding()
                    )
                
                    .padding(.bottom,7)
                TextComponent(text: "Set a password")
                RoundedRectangle(cornerRadius: 2)
                    .fill(Color.white)
                    .overlay(RoundedRectangle(cornerRadius: 2)
                        .stroke(Color.blue, lineWidth: 5).opacity(0.2))
                    .frame(maxWidth: .infinity, maxHeight: 50)
                    .padding(.horizontal, 10)
                    .overlay(
                        Text("•••••••••••")
                            .font(.title)
                            .fontWeight(.bold)
                            .frame(maxWidth: .infinity, maxHeight: 50, alignment: .leading)
                            .foregroundColor(Color.black)
                            .opacity(0.8)
                        
                        
                            .padding()
                    )
                    .overlay(
                        Text("|")
                            .font(.title)
                            .bold()
                            .frame(maxWidth: .infinity, maxHeight: 50, alignment: .leading)
                            .foregroundColor(Color.blue)
                            .opacity(0.4)
                            .padding(150)
                        
                    )
                
                
                    .overlay(
                        Image(systemName: "eye")
                            .frame(maxWidth: .infinity, maxHeight: 50, alignment: .trailing)
                            .foregroundColor(Color(UIColor.secondaryLabel))
                            .padding()
                    )
                
                
                    .padding(.bottom,28)
                
                NavigationLink(
                destination: Experiences_(),
                label: {
                RoundedRectangle(cornerRadius: 2)
              
                
                    .fill(Color("ActiveButton"))
                    .overlay(
                        RoundedRectangle(cornerRadius: 2)
                            .stroke(Color((UIColor.secondaryLabel)), lineWidth: 2).opacity(0.2))
                    .frame(maxWidth: .infinity, maxHeight: 50)
                    .padding(.horizontal, 10)
                    .overlay(
                        
                        Text("Continue")
                            .font(.title3)
                            .frame(maxWidth: .infinity, maxHeight: 50, alignment: .center)
                            .foregroundColor(Color.white)
                            .padding()
                    )
                })
                Spacer()
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=View@*/Color(red: 0.989, green: 0.984, blue: 0.989)/*@END_MENU_TOKEN@*/)
        }
    }
}


struct Sign_In_2_Previews: PreviewProvider {
    static var previews: some View {
        Sign_In_2()
    }
}
