//
//  Sign-In.swift
//  Notion
//
//  Created by Taghrid Alkwayleet on 28/10/1444 AH.
//
import SwiftUI

struct Sign_In: View {
    var body: some View {
        NavigationView {
            
            VStack(alignment: .leading, spacing:2) {
                
                Text("Cancel")
                    .foregroundColor(Color(UIColor.secondaryLabel))
                    .frame(maxWidth: .infinity, maxHeight: 55, alignment: .topLeading)
                    .padding()
                Text("Welcome To Notion")
                    .frame(maxWidth: .infinity, maxHeight: 40, alignment: .top)
                    .font(.title)
                    .bold()
                    .fontDesign(.rounded)
                Text("First, tell us a bit about yourself")
                    .frame(maxWidth: .infinity, maxHeight: 80, alignment: .top)
                    .foregroundColor(Color(UIColor.secondaryLabel))
                    .font(.title3)
                    .fontDesign(.rounded)
                
                TextComponent(text: "What should we call you?")
                FirstTextField()
                    .padding(.bottom,7)
                TextComponent(text: "Set a password")
                NewPassword()
                    .padding(.bottom,28)
                NavigationLink(
                destination: Sign_In_2(),
                label: {
                    UnActiveButton()
                })
                    Spacer()
                
            }
            .frame(maxWidth: .infinity, maxHeight: .infinity)
            .background(/*@START_MENU_TOKEN@*//*@PLACEHOLDER=View@*/Color(red: 0.989, green: 0.984, blue: 0.989)/*@END_MENU_TOKEN@*/)
        }
    }
    
    struct Sign_In_Previews: PreviewProvider {
        static var previews: some View {
            Sign_In()
        }
    }
}
