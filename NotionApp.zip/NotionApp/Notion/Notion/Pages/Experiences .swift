//
//  Experiences .swift
//  Notion
//
//  Created by Taghrid Alkwayleet on 30/10/1444 AH.
//

import SwiftUI

struct Experiences_: View {
    
    @State var function: [String] = ["Customer Service", "Design", "Product Management", "IT", "Finance","Sales","Human Resources", "Student", "Operation", "Educator", "Engineering", "Marketing", "Other"]
    
    
    var body: some View {
        NavigationView {
            VStack (alignment: .trailing, spacing: 0){
              
                NavigationLink(
                    destination: Team(),
                    label: {
                        Text("Done") 
                    })
                //                        .frame(width: .infinity, height: 50, alignment: .trailing)
                
                List {
                    
                    Section(
                        header: Text("Your Function")
                            .font(.title3)
                        // .padding(.bottom,-100)
                            .frame(maxWidth: .infinity, minHeight: 70, alignment: .center)
                            .border(.gray,width: 0.5)
                            .bold()
                            .foregroundColor(.black)
                            .background()
                            .padding(.horizontal,-25)
                            .padding(.bottom, 40)
                        
                        //    .padding(.vertical,)
                        
                        
                    ){
                        ForEach(function, id: \.self)
                        { function in
                            Text (function.capitalized)
                        }
                        .font(.title3)
                        // .padding(5)
                        // .padding()
                        
                    }
                    
                    
                }
                
            }
            
            .foregroundColor(.black)            .frame(maxWidth:.infinity,maxHeight: .infinity)
            //.padding(.horizontal,-20)
            .padding(.vertical,-10)
            .padding(.horizontal,8)
            
            
        }
        
    }
    }
    
    
    struct Experiences__Previews: PreviewProvider {
        static var previews: some View {
            Experiences_()
            
        }
        
    }

