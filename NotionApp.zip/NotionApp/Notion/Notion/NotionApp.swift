//
//  NotionApp.swift
//  Notion
//
//  Created by Taghrid Alkwayleet on 28/10/1444 AH.
//

import SwiftUI

@main
struct NotionApp: App {
    var body: some Scene {
        WindowGroup {
            Sign_In()
        }
    }
}
